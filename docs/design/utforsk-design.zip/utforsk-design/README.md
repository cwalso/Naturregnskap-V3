# Utforsk i kart – separat designprototype, versjon 2

Oppdatert designmock, 12.10.2026. Musehjul-zoom, større mobilkart og tydelig retur til kartlag ved 900 px er justert. Se `endringsrapport.html` for kort rapport og nye før-/etterbilder. Den opprinnelige designvurderingen er beholdt i `rapport.html`. Ingen produksjonsendring. Les `rapport.html` eller `rapport.md` for vurdering, skjermbilder og datagrense.

## Last ned pakken

Den komplette ZIP-filen ligger på en separat leveransebranch i det eksisterende repoet:

https://github.com/cwalso/Naturregnskap-V3/blob/design/utforsk-i-kart-2026-10-12/docs/design/utforsk-design.zip?raw=true

Pakk ut arkivet og åpne `utforsk-design/index.html`. Produksjonsrute, main, PR #76 og Pages er uendret.

## Åpne prototypen

`index.html` er ferdig bygget og inneholder React, CSS og kartbilder. Den kan åpnes i en vanlig nettleser uten npm-installasjon. I det administrerte arbeidsmiljøet blokkerer Chromium lokale file-URL-er; bruk lokal HTTP:

```bash
cd /workspace/outputs/utforsk-design
python -m http.server 4174 --bind 0.0.0.0
```

Åpne port **4174** i arbeidsmiljøets port-/forhåndsvisning. Prototypen ligger på `/`, rapporten på `/rapport.html`. Dette er en lokal forhåndsvisning, ikke publisering til GitHub Pages.

For utvikling fra kildekoden:

```bash
npm install
npm run dev
```

Åpne `http://localhost:4173/dev.html`. Utviklingsinngangen er separat fra den ferdig bygde `index.html`.

```bash
npm run lint
npm run build
PROTOTYPE_URL=http://localhost:4174/ npm run check:revision
```

Browserkontrollen bruker Chromium på `/usr/bin/chromium`. En annen installasjon kan angis med `CHROMIUM_PATH`. I dette miljøet ble kontrollen kjørt med nødvendig prosess-/sockettilgang. Se `revisjon/kontroller.json` for nye kontroller. `browser-checks.json` dokumenterer den opprinnelige leveransen.

## Hva som kan prøves

- Sju lag av/på, også alle av, og separate gjennomsiktighetskontroller.
- Verdsatte naturtyper: Naturtype og Verdikategori; søk og nullstilling.
- Klikk markøren eller Elvåsan sør 2 i listen for objektdetaljer.
- Grå arealenes tre kildeframstillinger og originale legendebilder.
- Samlet tegnforklaring, kilder, kildeforbehold og datoer.
- Desktop, 900 px og mobil; bunnpanel, Escape/fokusretur og kartets piltast-/zoomkontroller.
- `?stress=8` er en plassprøve med en ikke-interaktiv åttende rad. Det finnes fortsatt bare sju kartlag.

Kartdelen er en **bildemock basert på faktiske repo-/WMS-bilder**, ikke live kartdata. Naturtypevalget er avgrenset til én dokumentert lokalitet. Pan/zoom flytter og skalerer arkiverte bilder. Ingen analyser eller regnskapstall beregnes. Full produksjonsdatametode er uendret og skal gjenbrukes ved eventuell senere implementering.

Leveransen ligger utenfor V3-repoet. Ingen ny produksjonsrute, hosting, PR, merge eller main-endring.
