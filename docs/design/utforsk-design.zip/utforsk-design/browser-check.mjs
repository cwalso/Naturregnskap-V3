import { chromium } from 'playwright'
import assert from 'node:assert/strict'
import { mkdir, writeFile } from 'node:fs/promises'
const url=process.env.PROTOTYPE_URL||'http://localhost:4173/'
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']})
const page=await browser.newPage({viewport:{width:1440,height:960},reducedMotion:'reduce'})
const errors=[],checks=[],requests=[]
page.on('pageerror',e=>errors.push(e.message))
page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())})
await mkdir('skjermbilder',{recursive:true})
async function shot(name){
  await page.evaluate(()=>Promise.all([...document.images].map(i=>i.decode().catch(()=>{}))))
  await page.screenshot({path:`skjermbilder/${name}.png`,fullPage:false})
  const metrics=await page.evaluate(()=>{const map=document.querySelector('.map').getBoundingClientRect(),detail=document.querySelector('.detail-panel')?.getBoundingClientRect();return {viewport:{width:innerWidth,height:innerHeight},pageWidth:document.documentElement.scrollWidth,pageHeight:document.documentElement.scrollHeight,map:{x:map.x,y:map.y,width:map.width,height:map.height,bottom:map.bottom},detail:detail?{x:detail.x,y:detail.y,width:detail.width,height:detail.height}:null,transform:document.querySelector('.map-image-stack').style.transform}})
  assert(metrics.pageWidth<=metrics.viewport.width,`${name}: horizontal overflow`)
  assert(metrics.map.width>100&&metrics.map.height>=(metrics.viewport.height<800&&metrics.viewport.width<=700?120:180),`${name}: usable map remains visible`)
  if(metrics.viewport.width<=700&&metrics.detail)assert(metrics.map.bottom<=metrics.detail.y+1,`${name}: bottom sheet covers map`)
  checks.push({name,result:'passed',...metrics})
}
async function openSettings(name){await page.getByRole('button',{name:`Innstillinger for ${name}`,exact:true}).click()}
async function close(){await page.keyboard.press('Escape')}
async function filter(type='',value=''){await page.locator('#nature-type').selectOption(type);await page.locator('#value-category').selectOption(value)}
const transform=()=>page.locator('.map-image-stack').getAttribute('style')
try{
  await page.goto(url);await shot('01-desktop-1440-start')
  assert.equal(await page.getByRole('checkbox').count(),7)
  assert.equal(await page.getByRole('checkbox',{checked:true}).count(),1)
  await page.getByRole('checkbox',{name:'Verdsatte naturtyper',exact:true}).check();await shot('02-naturtyper-aktivert')
  await page.getByRole('button',{name:'Zoom inn',exact:true}).click()
  await page.locator('#map').focus();await page.keyboard.press('ArrowLeft');const before=await transform()
  await openSettings('Verdsatte naturtyper');await filter('Frisk lågurtfuruskog','Stor verdi')
  assert.equal(await transform(),before,'filter changed zoom/pan')
  await shot('03-naturtype-og-verdifilter')
  await page.getByRole('button',{name:'Vis hele kommunen',exact:true}).click()
  await page.getByRole('button',{name:'Vis lokalitet Elvåsan sør 2',exact:true}).click()
  assert(await page.getByRole('heading',{name:'Elvåsan sør 2',exact:true}).isVisible())
  assert(await page.getByText('2089403',{exact:true}).isVisible());await shot('04-valgt-objekt')
  await close();await page.getByRole('checkbox',{name:'Framtidig utbygging',exact:true}).check()
  await shot('05-tre-kartlag')
  await openSettings('Verdsatte naturtyper');await page.getByRole('button',{name:'Nullstill',exact:true}).click();await close()
  for(const name of ['Verneområder','Inngrepsfri natur (INON)','Villrein','Grå arealer'])await page.getByRole('checkbox',{name:new RegExp('^'+name.replace(/[()]/g,'\\$&'))}).check()
  await shot('06-sju-aktive-lag')
  await page.locator('.floating-legend').click();await shot('07-samlet-tegnforklaring')
  assert(await page.getByText('Status: januar 2023',{exact:true}).first().isVisible())
  assert(await page.getByText('Ingen registrerte leveområder i Trondheim i kildekontrollen',{exact:true}).count()>=1)
  await close();await openSettings('Grå arealer')
  for(const name of ['Grå arealer','Andel uten vegetasjon','Andel med vegetasjon']){
    await page.getByRole('radio',{name,exact:true}).check();await shot(`08-graa-${name==='Grå arealer'?'avgrensning':name==='Andel uten vegetasjon'?'uten-vegetasjon':'med-vegetasjon'}`)
  }
  const keep=await transform()
  const range=page.getByRole('slider',{name:'Gjennomsiktighet for Grå arealer',exact:true})
  await range.fill('100');assert.equal(await page.locator('[data-map-layer=grey]').evaluate(e=>getComputedStyle(e).opacity),'0');assert.equal(await transform(),keep)
  await shot('09-graa-helt-gjennomsiktig');await range.fill('50');await shot('10-graa-50-prosent');await close()
  await page.getByRole('button',{name:'Slå av alle',exact:true}).click();assert.equal(await page.locator('[data-map-layer]').count(),0);await shot('11-alle-lag-av')
  await page.setViewportSize({width:900,height:900});await page.goto(url);await shot('12-mellomstor-900-start')
  await page.getByRole('checkbox',{name:'Verdsatte naturtyper',exact:true}).check();await openSettings('Verdsatte naturtyper');await filter('Frisk lågurtfuruskog','Stor verdi');await shot('13-mellomstor-900-filter')
  const mapBox=await page.locator('.map').boundingBox();assert(mapBox.width>=600)
  await page.keyboard.press('Escape');assert.equal(await page.evaluate(()=>document.activeElement.getAttribute('aria-label')),'Innstillinger for Verdsatte naturtyper')
  await page.setViewportSize({width:390,height:844});await page.goto(url);await shot('14-mobil-390-start')
  await page.getByRole('button',{name:'Kartlag (1)',exact:true}).click();await shot('15-mobil-kartlag')
  await page.getByRole('checkbox',{name:'Verdsatte naturtyper',exact:true}).check()
  await page.getByRole('button',{name:'Innstillinger for Verdsatte naturtyper',exact:true}).click()
  await filter('Frisk lågurtfuruskog','Stor verdi')
  assert(await page.locator('#nature-type').isVisible());assert(await page.locator('#value-category').isVisible());await shot('16-mobil-naturtypefilter')
  await page.getByRole('button',{name:'Vis lokalitet Elvåsan sør 2',exact:true}).click();await shot('17-mobil-valgt-objekt')
  await page.locator('.detail-scroll').evaluate(e=>e.scrollTop=170);await shot('18-mobil-objekt-id');await close()
  await page.getByRole('button',{name:'Kartlag (2)',exact:true}).click();await page.getByRole('button',{name:'Slå av alle',exact:true}).click();await shot('19-mobil-alle-av')
  await page.setViewportSize({width:1440,height:960});await page.goto(url+'?stress=8');assert(await page.getByText('Plassprøve: rad 8').isVisible());assert.equal(await page.getByRole('checkbox').count(),7);await shot('20-otte-raders-plassproeve')
  await page.setViewportSize({width:320,height:720});await page.goto(url);await page.getByRole('button',{name:'Naturtypefilter',exact:true}).click();await filter('Frisk lågurtfuruskog','Stor verdi');await shot('21-smal-320-filter')
  await page.setViewportSize({width:720,height:480});await page.goto(url);await shot('22-reflow-720-480')
  assert.equal(errors.length,0,'JavaScript errors')
  assert(requests.every(r=>new URL(r).origin===new URL(url).origin),'prototype contacted external network')
  checks.push({name:'no-external-runtime-requests',result:'passed'},{name:'keyboard-escape-focus-return-and-map-pan',result:'passed'},{name:'filters-opacity-layer-choice-preserve-pan-zoom',result:'passed'},{name:'seven-layers-eight-row-capacity-no-new-layer',result:'passed'},{name:'zero-javascript-errors',result:'passed'},{name:'standalone-no-network',result:'not-tested-file-policy',note:'Local file URLs are blocked by the managed Chromium policy. HTTP preview of self-contained bundle was checked.'})
}catch(e){checks.push({name:'interrupted',result:'failed',message:e.message});throw e}
finally{await writeFile('browser-checks.json',JSON.stringify({date:'2026-10-12',url,checks,errors,networkRequests:requests},null,2));console.log(`${checks.filter(x=>x.result==='passed').length} kontroller bestått; ${errors.length} JavaScript-feil.`);await browser.close()}
