> Historikk: opprinnelig designvurdering, versjon 1. Se [kort endringsrapport for versjon 2](endringsrapport.md).

# Designvurdering: Utforsk i kart

12. oktober 2026 · Kommunale naturregnskap V3 · separat designleveranse

**Anbefaling:** Et kompakt, permanent lagpanel og ett kontekstavhengig detaljpanel. Kartet er hovedflaten. På mellomstore skjermer bruker lagvalg og detaljer samme sideplass; på mobil brukes et begrenset bunnpanel med kartet synlig over.

Dette er et designforslag, ikke en vedtatt produksjonsendring. Ingen produksjonskode, datametode, Pages-publisering, main eller PR #76 er endret. Den ferdige pakken leveres på en separat dokumentasjonsbranch for nedlasting.

## Utgangspunkt og etterprøvbarhet

GitHub-kontrollen bekreftet PR [#76](https://github.com/cwalso/Naturregnskap-V3/pull/76) som åpen og ikke merget. Branch `feat/explore-analysis-map` har faktisk HEAD **`fa6a0c938d83540ce5e8f9c18d5aa1787aef7333`**. Main er `a2e270dc7986cb2ce2f9a6c22ffe46e5aa7793db`.

Arbeidsmiljøets opprinnelige lokale HEAD var main-committen på branchen `work`; den lokale oppgavebranchen var eldre, `3e2b5df`. Vanlig git-fetch feilet fordi shell-proxyen ikke kunne nås. Dagens kode, dokumentasjon og bilder ble derfor lest med GitHub-connectoren på eksakt, bekreftet SHA. Ingen gammel lokal kode er presentert som dagens sjulagsløsning.

Vurderingen bygger på gjeldende `AGENTS.md`, dokumentasjonsoversikt, utviklingsplan, designføringer, arkitekturoversikt, `ExploreThemesWorkspace.tsx/.css`, `mapThemes.ts`, `exploreThemeMap.ts`, `municipalValuedNature.ts`, plansymbolikk og eksisterende tokens. Tidligere PR75-/kartakseptrapporter ga historisk kontekst. Dagens dokumentasjon og faktiske bilder veier tyngst:

- [Grå arealer: kildekontroll og 27 appbilder](https://github.com/cwalso/Naturregnskap-V3/blob/fa6a0c938d83540ce5e8f9c18d5aa1787aef7333/docs/validation/2026-10-12-grey-areas.md)
- [Seks kartlag: kildekontroll og visuell aksept](https://github.com/cwalso/Naturregnskap-V3/blob/fa6a0c938d83540ce5e8f9c18d5aa1787aef7333/docs/validation/2026-10-12-six-explore-layers.md)
- [Gjeldende designføringer](https://github.com/cwalso/Naturregnskap-V3/blob/fa6a0c938d83540ce5e8f9c18d5aa1787aef7333/docs/product/design-guidelines.md)

Originale, uredigerte førbilder ligger i `grunnlag/`: dagens sju lag, mobilens nedre panel og naturtypefilter med valgt objekt. `grunnlag/kildeoversikt.json` viser opphav. Historiske analysebilder er ikke brukt som bevis for dagens uavhengige kartlag.

## Dagens løsning: konkrete svakheter

Løsningen har allerede fungerende lagkombinasjoner, kommunemaske, kildesymboler, gjennomsiktighet og lokalitetsvalg. Problemet er primært plassering og prioritering. Kode og rapporter dokumenterer følgende:

| Område | Observasjon og konsekvens | Problemtype |
| --- | --- | --- |
| Sideoppbygging | Introduksjon, kart, lagvelger og en lang informasjonskolonne gir dokumentflyt fremfor en samlet arbeidsflate. | Design |
| Kartets plassering | Kartet har egen høyde på opptil 68 vh, men følger ikke brukeren ned til filtre og detaljer. Det står igjen stor tom plass under kartet mens sidekolonnen fortsetter. | Design / oppgaveløsning |
| Lagvelger | Grupperingen i tre faglige roller er god. Alle aktive lag utvider samtidig med range, status og eventuelle temavalg i en intern liste med maks 60 vh. Sju lag gir mye intern scrolling. | Design |
| Filtre | Naturtypefilteret ligger etter samtlige aktive tegnforklaringer. Det faktiske sjulagsbildet er 3762 px høyt. Filteret nås etter at kartet er ute av synsfeltet. | Funksjonelt hinder i brukerflyten |
| Tegnforklaringer | Symboler, kilde, dato og forbehold gjentas i lange blokker. Informasjonen er relevant, men skyver arbeidskontrollene ned. | Design + faglig informasjonsbehov |
| Objektinformasjon | Detaljer ligger etter lokalitetslisten og filtre. Koblingen kart → valgt objekt er vanskelig å følge når delene ligger langt fra hverandre. | Design |
| Informasjonshierarki | Avkryssing, opasitet, fagrolle, status og forklaring konkurrerer. En enkel av/på-oppgave utløser mye informasjon. | Design |
| Visuell kompleksitet | Sju lag har mange ulike faglige farger og mønstre. UI-et trenger roligere flater og en tydelig forklaring av hvilke lag som faktisk ligger over andre. | Design / kartlesing |
| Responsivitet | Ved 900 px og mindre går dagens layout over til kontroller → kart → informasjon. Mobilvelgeren kan lukkes, men filtrene ligger fortsatt under kartet. Ingen horisontal overflow i tidligere kontroller løser ikke dette vertikale problemet. | Design / oppgaveløsning |
| Tilgjengelighet | Dagens kode har labels, fieldsets, synlig fokus og kontroller på minst 44 px. Lang navigasjonsrekkefølge og avstand mellom handling/resultat øker likevel belastningen ved tastaturbruk og forstørring. | Universell utforming |

Faglige krav skal ikke fjernes for å spare plass: regnskapsgrunnlag, plandata og supplerende temadata må skilles; INON må vise januar 2023; grått betyr ikke ledig areal; manglende registrering er ikke manglende naturverdi. Tomt utsnitt, ukjent dekning og kildefeil trenger ulike tekster. Dette er informasjonsbehov, ikke argumenter for flere GIS-funksjoner.

## Tre layoutalternativer

Vurderingene gjelder kommunal arealplanlegging med de eksisterende sju lagene. «God» betyr støtte til oppgaven, ikke bare visuelt uttrykk.

| Kriterium | 1: Fast venstre + fast høyre panel | 2: Flytende/uttrekkbare paneler | 3: Kompakt lagpanel + detaljer ved behov |
| --- | --- | --- | --- |
| Kartplass | To paneler bruker plass også uten detaljer. | Mest kartplass når panelene er lukket; åpne paneler dekker kartinnhold. | Stor kartflate som standard; detaljene tar bare plass når de trengs. |
| Enkel av/på | God direkte tilgang, men tre flater virker omfattende. | Krever først å finne/åpne lagvelgeren. | God direkte tilgang uten å åpne innstillinger. |
| Sju–åtte lag | God listeoversikt, men kartet blir smalt. | Laglisten trenger scrolling og kan dekke interessante steder. | Kun kompakte rader; innstillinger for ett lag om gangen. |
| Filtrering | God samtidighet på store skjermer. | Filteret er tilgjengelig, men ligger potensielt over treffene. | Filterets lagnavn, kart og status vises samtidig. |
| Objektinformasjon | Lett å finne, men et tomt panel opptar plass. | Popup/panel kan skjule lokaliteten. | Ett detaljpanel bytter mellom filter og valgt objekt. |
| Mobil | Må likevel bygges om til ett panel. | Godt egnet, men overlapp og lukkemønster må styres. | Godt egnet med samme panelmodell og begrenset bunnpanel. |
| Tilgjengelighet | Forutsigbar plassering; lang fokusrekkefølge. | Krever særlig kontroll av fokus, lagdeling og skjulte kontroller. | Forutsigbar lagliste, tydelig paneleier, fokus tilbake ved lukking. |
| Implementering | Moderat; enkel desktop, egen mobilvariant. | Moderat–høy; mer overlay-, fokus- og posisjonslogikk. | Moderat; responsive rutenett og ett kontrollert panel. |

**Anbefalt kombinasjon:** Alternativ 3 på desktop, med uttrekkbar panelmodell fra alternativ 2 på mobil. Ved 900 px gjenbrukes venstrepanelets plass til detaljer. Dette unngår tre smale kolonner. Kartet trenger ikke fri panelplassering, flyttbare vinduer, lagreordering eller en GIS-verktøykasse.

Kompromisset er én ekstra handling for å justere gjennomsiktighet. På 900 px må brukeren gå tilbake til laglisten for å slå andre lag av/på. På mobil er kartet mindre under filtrering. Dette er tydeligere og mer stabilt enn å legge alle innstillinger permanent ved kartet.

## Anbefalt interaksjon og informasjonshierarki

1. Start med Grunnkart nivå 0 aktivert og øvrige lag av. Etiketter og avkryssing brukes til enkle lagvalg.
2. Knappen ved hver rad åpner innstillinger med lagnavnet øverst. Den kan også forklare et avslått lag uten automatisk å aktivere det.
3. For Verdsatte naturtyper prioriteres Naturtype og Verdikategori. Søk i naturtypenavn ligger i et sammenleggbart felt. Nullstill påvirker bare dette laget.
4. Aktivt filter vises både i lagraden og i en kompakt markør ved kartet. Filterendring oppdaterer kartpresentasjonen straks og beholder zoom/pan.
5. Gjennomsiktighet er en prosentkontroll i lagets eget panel: 0 % = ugjennomsiktig, 100 % = helt gjennomsiktig. En aktiv rad merkes «Helt gjennomsiktig» ved 100 %.
6. Grå arealer har tre radiovalg med eksisterende navn. Kildens tegnforklaring følger valgt framstilling. Det gjøres ingen nye prosentberegninger.
7. Tegnforklaringen åpnes ved behov, viser bare aktive lag og følger tegnerekkefølgen fra øverst til nederst. Kilde og forbehold kan utvides per lag. INON-dato og relevante kildeforbehold er synlige uten å åpne metadata.
8. Kartmarkør eller lokalitetsliste åpner samme objektdetalj. Panelet prioriterer navn, naturtype og verdi, deretter valgt kommunekontekst, objekt-ID, kilde-ID og kilde. Det finnes en tydelig retur til filteret.
9. Ved mange aktive lag gis en snarvei til tegnforklaringen. Den faste tegnerekkefølgen beholdes. Hvert lag kan dempes; det beregnes ikke overlapp.
10. Alle av gir en tydelig tekst om at bakgrunnskartet fortsatt vises. Bare «Vis hele kommunen» nullstiller utsnittet; vanlig lagvalg, filter og objektvalg gjør ikke det.

**Objektavgrensning:** Prototypen demonstrerer eksisterende naturtypeinspeksjon. Den lover ikke objektinformasjon for vern, INON, villrein, Grå arealer, plan eller nivå 0. Gråarealenes teknisk queryable WMS er ikke i seg selv dokumentasjon på en ferdig attributtflyt. Kommunen vises som kartkontekst, ikke som et nytt attributt på lokaliteten.

## Faktisk visuell prototype og datagrense

`index.html` er en selvstendig, bygget React/TypeScript-prototype. Den inkluderer CSS og lokale kartbilder. Den trenger ingen data-API-er ved visning. Kildekode, Vite-inngang og byggeskript følger med; ingenting monteres i ordinær V3-rute.

Kartdelen er tydelig merket **designmock med arkiverte kartbilder**. Bildene kommer fra faktiske valideringsbilder og WMS-kildebilder i repoet. Kartbakgrunnen er beskåret, de gamle innbakte zoom-/infokontrollene fjernet fra denne avledede illustrasjonen, og fargelag skilt ut fra skjermbilder. WMS-kildebilder er skalert til det dokumenterte felles utsnittet og visuelt begrenset med illustrasjonens nivå-0-mask. Native legendebilder beholdes. Originale førbilder er uredigerte.

Av/på og gjennomsiktighet fungerer uavhengig for sju lag. Verdikategorifilteret skiller illustrasjonspiksler; naturtypefilteret demonstrerer kun **Frisk lågurtfuruskog / Elvåsan sør 2**. Denne lokaliteten, verdien Stor verdi, objekt-ID `2089403` og kilde-ID `VKU-NINFP2510188746` er lest fra faktisk valideringsbilde. Den større kartmarkøren er en designillustrasjon av dette dokumenterte valget, ikke en ny geometri.

Dette er ikke live datakall, en implementering av den romlige filtermetoden, en ny lokalitetsinventering eller produksjonskartografisk validering. Bildefilteret erstatter ikke `filterRegisteredNature` i V3. Ingen oppdiktede analyse-, areal-, overlapps- eller regnskapstall vises. Villrein i Trondheim er en dokumentert tom registrering i kildekontrollen; det tegnes ikke oppdiktede leveområder. FKB-Grønnstruktur er utelatt.

## Skjermstørrelser og sju–åtte lag

| Størrelse | Utforming | Målt kartflate i prototypen |
| --- | --- | --- |
| 1440 × 960 | Lagpanel 274 px. Detaljpanel 338 px åpnes ved behov. Begge kan brukes sammen med kartet. | 1166 px bredt uten detaljer, 828 px med detaljer; kartet er 712 px høyt. Omtrent 81 % / 58 % av skjermbredden. |
| 900 × 900 | Sidepanel 252 px. Detaljer erstatter laglisten i samme plass. Retur og Kartlag-knapp gjør byttet tydelig. | 648 × 652 px; 72 % av skjermbredden. |
| 390 × 844 | Lag og detaljer i ett bunnpanel. Filtervalg øverst, resten med intern scrolling. Kartet får egen plass over panelet. | Kartet er 390 × 232 px med åpne filtre; begge select-kontrollene er synlige. Det dekkes ikke av bunnpanelet. |

Målingene gjelder kontrollenes layout, ikke kartdataenes oppløsning. På mobil bevares pan-/zoomtilstanden, mens illustrasjonen tilpasser størrelse til tilgjengelig flate. I eventuell produksjonsimplementering må eksisterende OpenLayers-instans bevare senter/oppløsning og bruke sin eksisterende resize-logikk.

Sju lag er fullt interaktive i mocken. Åtte rader er plassprøvd med `?stress=8`: en **ikke-interaktiv testrad**, uten ny datakilde, avkryssing eller aktivt lag. Listen har uavhengig scrolling og samme struktur uansett antall rader. Ingen FKB-kontroll eller fiktivt åttende kartlag er lagt til. Et faktisk åttende lag krever fortsatt faglig beslutning og kilde-/rettighetsavklaring.

## Brukersituasjoner og skjermbilder

Alle bildene nedenfor er uredigerte screenshots fra den faktiske, kjørende designprototypen, ikke tegnede visninger av det som burde være implementert.

| Situasjon | Dokumentasjon |
| --- | --- |
| 1. Åpne med Grunnkart nivå 0 | [Desktop](skjermbilder/01-desktop-1440-start.png) |
| 2. Slå på Verdsatte naturtyper | [Aktivert](skjermbilder/02-naturtyper-aktivert.png) |
| 3. Naturtype og verdi mens kartet synes | [Desktop](skjermbilder/03-naturtype-og-verdifilter.png), [900 px](skjermbilder/13-mellomstor-900-filter.png), [mobil](skjermbilder/16-mobil-naturtypefilter.png) |
| 4. Velge faktisk eksempellokalitet | [Desktop](skjermbilder/04-valgt-objekt.png), [mobil](skjermbilder/17-mobil-valgt-objekt.png), [ID-er i mobilpanelet](skjermbilder/18-mobil-objekt-id.png) |
| 5. Grunnkart + plan + naturtyper | [Tre lag](skjermbilder/05-tre-kartlag.png) |
| 6. Vern, INON og Villrein | [Sju lag aktivert](skjermbilder/06-sju-aktive-lag.png), [kildesymboler og forklaringer](skjermbilder/07-samlet-tegnforklaring.png) |
| 7. Grå arealenes framstillinger | [Avgrensning](skjermbilder/08-graa-avgrensning.png), [uten vegetasjon](skjermbilder/08-graa-uten-vegetasjon.png), [med vegetasjon](skjermbilder/08-graa-med-vegetasjon.png) |
| 8. Mange lag og lesing av kartet | [Samlet tegnforklaring](skjermbilder/07-samlet-tegnforklaring.png), [plassprøve åtte rader](skjermbilder/20-otte-raders-plassproeve.png) |
| 9. Alle lag av | [Desktop](skjermbilder/11-alle-lag-av.png), [mobil](skjermbilder/19-mobil-alle-av.png) |
| 10. Mobil | [Start](skjermbilder/14-mobil-390-start.png), [lagvelger](skjermbilder/15-mobil-kartlag.png), [filter](skjermbilder/16-mobil-naturtypefilter.png) |

## Universell utforming og browserkontroll

Designet bruker native checkbox/radio/select/range, tilknyttede labels, fieldsets, tydelige paneltitler og synlig fokus. Ikonknapper har tilgjengelige navn. Lagstatus og filtertilstand formidles med tekst og avkryssing. Kartmarkøren har et alternativ i lokalitetslisten; øvrige lag er også forklart som tekst. Mobilkontrollene og laginnstillingene er minst 44 px. Bunnpanelene er ikke modale: kart og nederste navigasjon forblir tilgjengelige, uten en fokusfelle. Escape lukker panel og returnerer fokus til åpneren. Kartutsnittet kan flyttes med piltaster; pluss/minus zoomer illustrasjonen.

Chromium-kontrollen ga **29 beståtte kontroller, 24 screenshots og 0 JavaScript-feil**. Kontrollene omfattet 1440, 900, 390 og 320 px, 720 × 480 reflow, lagvalg, samtidig naturtype/verdi, kartmarkør/objekt, gråarealframstilling, 50/100 % gjennomsiktighet, alle av, åtte rader, Escape/fokusretur og uendret pan-/zoomtilstand. Ingen horisontal overflow i de kontrollerte visningene. Mobilens kartareal ble eksplisitt målt utenfor bunnpanelet. Resultatene ligger i `browser-checks.json` og skriptet er kjørbart på nytt.

Dette er ikke en full WCAG 2.2 AA-revisjon. Skjermleser med reell langt kommuneliste, OS-tekstforstørring, tvungen høykontrast og berøring på fysisk mobil må prøves ved implementering. Svært lave skjermer har fallback med vanlig sidescrolling. Innsyn i feil/lasting og ukjent datadekning er dokumentert som krav, men ikke simulert som live datatilstander i denne bildemocken.

Det administrerte Chromium-miljøet blokkerer `file://`-URL-er. Den selvstendige HTML-filen er derfor kontrollert over lokal HTTP. Den har innebygde bilder/React/CSS og trenger ingen eksterne kartforespørsler. Ingen ny hosting, repo eller workflow er opprettet.

## Gjenbruk og estimert implementeringsomfang

| Eksisterende del | Gjenbruk ved eventuell senere implementering |
| --- | --- |
| `mapThemes.ts` | Navn, tre fagroller, defaults, fast tegnerekkefølge, kilder, tre gråarealvalg og legendereferanser. |
| `ExploreThemesWorkspace` | Lagtilstand, naturtypevalg, kommuneeier, valgt ID og uavhengighet mellom lag. Presentasjon kan deles i lagliste og detaljpanel. |
| `createExploreLayerMap` / `exploreThemeMap.ts` | Én kartinstans, eksisterende lag og kommunemaske, statushåndtering, utvalg og eksplisitt kommune-reset. |
| `municipalValuedNature.ts` | Uendret REST-metode, `getMunicipalValuedNature`, `filterRegisteredNature`, kildesporbarhet og kommunerelevante naturtypenavn. |
| `ServiceLegend` og `futureDevelopmentSymbology` | Kildens legend og eksisterende planskravur; ikke omtegne fagkartografi etter profilfarger. |
| V3 tokens, header og kommunevalg | Nøytral avsender, teststatus, sjøgrønn/krem og etablert typografifamilie. |

Estimat for en avgrenset frontend-implementering: **5–8 dagsverk**, etter designbeslutning. Cirka 2–3 til responsive paneler og tilstand/fokus, 1–2 til kobling av eksisterende filtre/objekt/legender og 2–3 til regresjon, tilgjengelighet, reelle karttjenester og dokumentasjon. Estimatet omfatter ingen ny data-/analysemetode, nasjonal preparation eller innføring av FKB. Brukertest og en full tilgjengelighetsrevisjon må planlegges særskilt.

## Risikoer og åpne designvalg

- Panelåpning kan fortrenge en lokalitet på smale skjermer. Prøv løsningen med faktiske plansaker; produksjonskartets senter/oppløsning må beholdes ved resize.
- Mange aktive lag er fortsatt kartografisk krevende. Den nye plasseringen gjør forklaringen tilgjengelig, men kan ikke fjerne tematiske overlapp.
- Den komplette listen med 90 naturtyper / 1529 registreringer fra kildekontrollen må prøves med søk og paging i den eksisterende datamodellen. Mocken demonstrerer én dokumentert type, og lager ingen ny kommunetotal.
- Vurder om naturtypefilter skal åpnes automatisk ved aktivering. Forslaget lar enkel av/på forbli enkel; panel åpnes eksplisitt på desktop.
- Prøv ordet «Gjennomsiktighet» med brukere; prosentretningen følger dagens løsning og forklares med to endepunkter.
- Bevar kildeversjoner, datadatoer, grov målestokk, teknisk feil og ukjent dekning per lag. Gråarealenes 1:250 000-grense trenger eksisterende produksjonsstatus, ikke automatisk zoom.
- Objektinspeksjon for andre lag krever egen dokumentert kilde- og attributtvurdering. Det er ikke del av dette forslaget.
- FKB-Grønnstruktur skal fortsatt være utilgjengelig i offentlig prototype til rettighetene er avklart.

## Opprettede filer og avslutning

Hele leveransen ligger separat i arbeidsmiljøets `outputs/utforsk-design/`. Ingen produksjonsfiler er endret. ZIP-pakken og en kort nedlastingsveiledning legges i `docs/design/` på den separate branchen `design/utforsk-i-kart-2026-10-12`; main og PR #76 berøres ikke. Den opprinnelig foreskrevne `/codex/.../output`-mappen finnes ikke i det tilknyttede skymiljøet og kunne ikke opprettes med miljøets filrettigheter; leveransen er derfor lagret i tilgjengelig arbeidsområde.

- `index.html`: selvstendig visuell prototype.
- `rapport.md`, `rapport.html`: designvurdering og bildegalleri.
- `README.md`: åpning, utvikling og kontroll.
- `src/App.tsx`, `src/main.tsx`, `src/style.css`, `src/assets.ts`: separat React/TypeScript-kilde og innebygde bildeassets.
- `package.json`, `tsconfig.json`, `eslint.config.js`, `dev.html`, `build.mjs`: isolert utviklings- og byggoppsett.
- `browser-check.mjs`, `browser-checks.json`: egne browserkontroller og resultater. Lint-/bygglogger følger med.
- `assets/`: 20 avledede/arkiverte kart- og legendefiler; opphav er dokumentert.
- `skjermbilder/`: 24 uredigerte screenshots fra prototypen.
- `grunnlag/`: tre originale førbilder og kildeoversikt.
- `filer.json`: full filoversikt med SHA-256, generert ved pakking.

Designvalget er dokumentert i denne rapporten som forslag. Levende produktdokumentasjon og ADR-er i repoet er ikke oppdatert til å framstille et uimplementert design som gjeldende løsning. Arbeidet stopper etter denne designleveransen: ingen produksjonsimplementering, merge, PR-opprettelse eller Pages-publisering. Den separate leveransebranchen tilbyr bare arkivet for nedlasting.
