import { build } from 'esbuild'
import { readFile, writeFile } from 'node:fs/promises'
const result=await build({entryPoints:['src/main.tsx'],bundle:true,write:false,minify:true,format:'iife',jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'},outdir:'build'})
const js=result.outputFiles.find(f=>f.path.endsWith('.js')).text.replaceAll('</script','<\\/script')
const css=result.outputFiles.find(f=>f.path.endsWith('.css')).text
await writeFile('index.html',`<!doctype html><html lang="nb"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Utforsk i kart · Designprototype</title><style>${css}</style></head><body><div id="root"></div><script>${js}</script></body></html>`)
console.log('Selvstendig index.html bygget. React, CSS og kartbilder er inkludert; ingen runtime-nettverk nødvendig.')
