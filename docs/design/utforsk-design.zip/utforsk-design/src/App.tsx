import { useCallback, useEffect, useRef, useState } from 'react'
import { assets } from './assets'
import './style.css'

type LayerId = 'level0' | 'plan' | 'nature' | 'protected' | 'inon' | 'reindeer' | 'grey'
type Layer = {id: LayerId; name: string; group: string; transparency: number; image?: string; source: string; note: string; reference?: string; legend?: string}
const layers: Layer[] = [
  {id:'level0',name:'Grunnkart nivå 0',group:'Regnskapsgrunnlag',transparency:30,image:'level0.png',source:'NIBIO · Grunnkart for arealanalyse 2025',note:'Heldekkende inndeling i Natur, Jordbruk og Bebygd. Vann er kontekst. Det klargjorte oversiktsrasteret finnes foreløpig for Trondheim.'},
  {id:'plan',name:'Framtidig utbygging',group:'Plandata',transparency:0,image:'plan.png',source:'DiBK · kommuneplanens arealdel',note:'Natur og Jordbruk innenfor framtidige utbyggingsformål. Bebygd og vann er skjult. Kartvisningen er ikke bokført naturtap eller en prognose.'},
  {id:'nature',name:'Verdsatte naturtyper',group:'Supplerende temadata',transparency:0,image:'nature-all.png',source:'Miljødirektoratet · naturtyper med KU-verdi',note:'Registrerte lokaliteter, også de som krysser kommunegrensen. Datasettet er ikke heldekkende. Manglende registrering betyr ikke fravær av naturverdi.'},
  {id:'protected',name:'Verneområder',group:'Supplerende temadata',transparency:0,image:'vern-5001.png',source:'Miljødirektoratet · vedtatt vern',note:'Kildens fem verneformer. Foreslått vern vises ikke. Formelt vern dokumenterer ikke alene naturtilstand.',reference:'Vedtatt vern · løpende kilde',legend:'vern-legend.png'},
  {id:'inon',name:'Inngrepsfri natur (INON)',group:'Supplerende temadata',transparency:35,image:'inon-5001.png',source:'Miljødirektoratet · inngrepsfri natur 01.2023',note:'Avstand fra tyngre tekniske inngrep: 1–3 km, 3–5 km og minst 5 km. Supplerende indikator; ikke økosystemtype eller naturtilstand.',reference:'Status: januar 2023',legend:'inon-legend.png'},
  {id:'reindeer',name:'Villrein',group:'Supplerende temadata',transparency:0,source:'Villreinbasen · Miljødirektoratet',note:'Registrerte biologiske leveområder i Sør-Norge. Dette er ikke dyreposisjoner eller regionale planers soner.',reference:'Ingen registrerte leveområder i Trondheim i kildekontrollen',legend:'reindeer-legend.png'},
  {id:'grey',name:'Grå arealer',group:'Supplerende temadata',transparency:25,image:'graa_arealer-5001.png',source:'Miljødirektoratet, Kartverket, NIBIO og SSB · WMS: NIBIO',note:'Grått betyr ikke ledig areal eller fortettingspotensial. Ikke identisk med Bebygd i nivå 0. Vegetasjonsandelene er kildeestimater per objekt, ikke kommunale andeler.',reference:'Testversjon 1 · sammensatt kildegrunnlag fra 2025 og andre år',legend:'graa_arealer-legend.png'},
]
const zOrder: LayerId[]=['level0','grey','inon','reindeer','plan','nature','protected']
const categories=['Svært stor verdi','Stor verdi','Middels verdi','Noe verdi']
const colors=['#AF0C0C','#FD7032','#FEC02D','#FFFE37']
const example={name:'Elvåsan sør 2',type:'Frisk lågurtfuruskog',value:'Stor verdi',id:'2089403',sourceId:'VKU-NINFP2510188746'}
const groups=['Regnskapsgrunnlag','Plandata','Supplerende temadata']
const greyOptions=[['graa_arealer','Grå arealer'],['andel_uten_vegetasjon','Andel uten vegetasjon'],['andel_med_vegetasjon','Andel med vegetasjon']]

function Icon({name}:{name:string}) {
  const paths:Record<string,string>={layers:'m3 7 9-5 9 5-9 5-9-5Zm0 5 9 5 9-5M3 17l9 5 9-5',close:'m6 6 12 12M18 6 6 18',settings:'M4 6h16M4 12h16M4 18h16M8 3v6M16 9v6M10 15v6',arrow:'m9 5 7 7-7 7',back:'m15 5-7 7 7 7',plus:'M12 5v14M5 12h14',minus:'M5 12h14',reset:'M4 9V4h5M4 4l4 4a7 7 0 1 1-2 8',info:'M12 11v6M12 7h.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Z',search:'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Z',pin:'M19 9c0 5-7 13-7 13S5 14 5 9a7 7 0 1 1 14 0ZM15 9a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z',legend:'M5 5h3v3H5ZM12 6h8M5 12h3v3H5ZM12 13h8M5 19h3v3H5ZM12 20h8',map:'m3 5 6-3 6 3 6-3v17l-6 3-6-3-6 3V5Zm6-3v17M15 5v17'}
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]||paths.info}/></svg>
}
function Legend({layer,grey}:{layer:Layer;grey:string}){
    if(layer.id==='level0')return <ul className="symbols">{['Natur','Jordbruk','Bebygd','Vann (kontekst)'].map((n,i)=><li key={n}><i style={{background:['#9ECC73','#FFD16E','#E86474','#6BAED6'][i]}}/>{n}</li>)}</ul>
    if(layer.id==='nature')return <ul className="symbols">{categories.map((n,i)=><li key={n}><i style={{background:colors[i]}}/>{n}</li>)}</ul>
    if(layer.id==='plan')return <ul className="symbols"><li><i className="hatch nature"/>Natur i framtidige utbyggingsformål</li><li><i className="hatch agriculture"/>Jordbruk i framtidige utbyggingsformål</li></ul>
    return <img className="service-legend" src={assets[layer.id==='grey'?`${grey}-legend.png`:layer.legend!]} alt={layer.id==='grey'?`${greyOptions.find(o=>o[0]===grey)?.[1]}: kildens tegnforklaring`:`${layer.name}: kildens tegnforklaring`}/>
  }
function SourceInfo({layer}:{layer:Layer}){return <details className="source-details"><summary>Kilde og forbehold</summary><p>{layer.source}</p>{layer.reference&&<p>{layer.reference}</p>}<p>{layer.note}</p><a href={layer.id==='grey'?'https://data.norge.no/nb/data-services/f241d863-8e66-3b23-b740-bfe6f1a5af80/kart-over-gra-arealer-wms-testversjon-1':'https://github.com/cwalso/Naturregnskap-V3/blob/fa6a0c938d83540ce5e8f9c18d5aa1787aef7333/apps/web/src/features/explore-map/mapThemes.ts'} target="_blank" rel="noreferrer">Kildedokumentasjon ↗</a></details>}

export default function App(){
  const [active,setActive]=useState<LayerId[]>(['level0'])
  const [transparency,setTransparency]=useState<Record<string,number>>(Object.fromEntries(layers.map(l=>[l.id,l.transparency])))
  const [panel,setPanel]=useState<null|LayerId|'legend'|'object'|'help'>(null)
  const [layerOpen,setLayerOpen]=useState(false)
  const [natureType,setNatureType]=useState('')
  const [value,setValue]=useState('')
  const [search,setSearch]=useState('')
  const [grey,setGrey]=useState('graa_arealer')
  const [selected,setSelected]=useState(false)
  const [scale,setScale]=useState(1)
  const [offset,setOffset]=useState({x:0,y:0})
  const [notice,setNotice]=useState('Grunnkart nivå 0 er aktivert.')
  const returnFocus=useRef<HTMLElement|null>(null)
  const panelRef=useRef<HTMLElement>(null)
  const drag=useRef<{x:number;y:number;startX:number;startY:number}|null>(null)
  const source=layers.find(l=>l.id===panel)
  const filtered=!!natureType||!!value
  const sampleVisible=active.includes('nature')&&(!value||value===example.value)
  const stress=new URLSearchParams(location.search).get('stress')==='8'
  function open(next:typeof panel){returnFocus.current=document.activeElement as HTMLElement;setPanel(next);setLayerOpen(false)}
  const close=useCallback(()=>{setPanel(null);setLayerOpen(false);requestAnimationFrame(()=>returnFocus.current?.focus())},[])
  function toggle(id:LayerId){
    const showing=!active.includes(id);setActive(p=>showing?[...p,id]:p.filter(x=>x!==id))
    setNotice(`${layers.find(l=>l.id===id)?.name} er ${showing?'aktivert':'slått av'}.`)
    if(id==='nature'&&!showing){setSelected(false);if(panel==='object'||panel==='nature')setPanel(null)}
  }
  function changeFilter(type:string,category:string){setNatureType(type);setValue(category);setSelected(false);setNotice(type?`${example.type}: ${!category||category===example.value?'én dokumentert lokalitet i designutvalget':'ingen lokaliteter i designutvalget'}.`:`Verdikategori: ${category||'alle'}.`)}
  function chooseObject(){if(sampleVisible){setSelected(true);open('object');setNotice(`${example.name} er valgt.`)}}
  function reset(){setOffset({x:0,y:0});setScale(1);setNotice('Hele kommuneutsnittet vises.')}
  useEffect(()=>{if(panel){panelRef.current?.querySelector<HTMLButtonElement>('button')?.focus()}},[panel])
  useEffect(()=>{const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'){close()}};window.addEventListener('keydown',escape);return()=>window.removeEventListener('keydown',escape)},[close])
  return <>
    <a className="skip" href="#map">Hopp til kartet</a>
    <header className="site-header"><div className="brand"><Icon name="map"/><strong>Kommunale naturregnskap</strong><span className="test-tag">TEST</span></div><span className="header-context"><Icon name="pin"/>Trondheim <span className="municipal-number">5001</span></span><button className="header-help" onClick={()=>open('help')} aria-label="Om designprototypen"><Icon name="info"/></button></header>
    <div className="page-heading"><div><p className="eyebrow">Naturregnskap / Kart</p><h1>Utforsk i kart</h1></div><p className="heading-description">Se datagrunnlaget. Kombiner kartlag.<br/>Undersøk registrert natur.</p><span className="prototype-tag">Designprototype</span></div>
    <main className={`workspace ${panel?'has-detail':''} ${layerOpen?'layers-open':''}`}>
      <aside className="layer-panel" aria-label="Kartlag" hidden={false}>
        <div className="panel-heading"><h2><Icon name="layers"/>Kartlag</h2><span className="counter">{active.length} aktive</span><button className="mobile-close icon-button" onClick={()=>setLayerOpen(false)} aria-label="Lukk kartlag"><Icon name="close"/></button></div>
        <p className="panel-intro">Velg hva du vil se i kartet.</p>
        <div className="layer-scroll">{groups.map(group=><fieldset key={group}><legend>{group}</legend>{layers.filter(l=>l.group===group).map(l=><div className={`layer-row ${active.includes(l.id)?'is-active':''}`} key={l.id}>
          <label className="layer-label"><input type="checkbox" checked={active.includes(l.id)} onChange={()=>toggle(l.id)}/><span>{l.name}{l.id==='inon'&&<small>Januar 2023</small>}{active.includes(l.id)&&transparency[l.id]===100&&<small>Helt gjennomsiktig</small>}{l.id==='nature'&&filtered&&<small className="filter-indicator">Filter aktivt</small>}</span></label>
          <button className="icon-button layer-settings" onClick={()=>open(l.id)} aria-label={`Innstillinger for ${l.name}`} aria-expanded={panel===l.id}><Icon name="settings"/></button>
        </div>)}</fieldset>)}
        {stress&&<div className="stress-row">Plassprøve: rad 8<br/><small>Ingen ny datakilde eller avkryssing</small></div>}
        <div className="layer-footnote"><Icon name="info"/><p>Temadata supplerer regnskapsgrunnlaget. Lagvalg starter ingen analyse.</p></div>
        </div>
        <div className="layer-actions"><button className="text-button" onClick={()=>{setActive([]);setSelected(false);setPanel(null);setNotice('Alle kartlag er slått av. Bakgrunnskartet vises.')}} disabled={!active.length}>Slå av alle</button><button className="text-button" onClick={()=>open('legend')}><Icon name="legend"/>Tegnforklaring</button></div>
      </aside>
      <section className="map-column" aria-label="Kartarbeidsflate">
        <div className="map-toolbar"><button className="tablet-layer-button" onClick={()=>{setLayerOpen(!layerOpen);setPanel(null)}} aria-expanded={layerOpen}><Icon name="layers"/>Kartlag · {active.length}</button><span className="map-context"><Icon name="pin"/>Trondheim <span>· Kommuneutsnitt</span></span><button className="reset-button" onClick={reset}><Icon name="reset"/><span>Vis hele kommunen</span></button></div>
        <div id="map" className="map" role="region" tabIndex={0} aria-label="Kartutsnitt fra faktisk validering i Trondheim" aria-describedby="map-instructions" onKeyDown={e=>{const keys:Record<string,[number,number]>={ArrowLeft:[35,0],ArrowRight:[-35,0],ArrowUp:[0,35],ArrowDown:[0,-35]};if(keys[e.key]){e.preventDefault();const [x,y]=keys[e.key];setOffset(p=>({x:p.x+x,y:p.y+y}))}if(e.key==='+'){setScale(p=>Math.min(3,p+.2))}if(e.key==='-'){setScale(p=>Math.max(.8,p-.2))}}}>
          <p id="map-instructions" className="sr-only">Designmock med arkiverte kartbilder. Pilene flytter utsnittet. Pluss og minus zoomer i bildet. Velg den dokumenterte lokaliteten med kartmarkøren eller i lokalitetslisten.</p>
          <div className="map-drag-surface" onPointerDown={e=>{drag.current={x:e.clientX,y:e.clientY,startX:offset.x,startY:offset.y};e.currentTarget.setPointerCapture(e.pointerId)}} onPointerMove={e=>{if(drag.current){setOffset({x:drag.current.startX+e.clientX-drag.current.x,y:drag.current.startY+e.clientY-drag.current.y})}}} onPointerUp={()=>{drag.current=null}} onPointerCancel={()=>{drag.current=null}}>
          <div className="map-image-stack" style={{transform:`translate(${offset.x}px,${offset.y}px) scale(${scale})`}}>
            <img src={assets['background.png']} alt="" draggable={false}/>
            {zOrder.filter(id=>active.includes(id)).map(id=>{const l=layers.find(l=>l.id===id)!;let image=l.image;if(id==='grey')image=grey+'-5001.png';if(id==='nature')image=natureType?'nature-sample.png':value?`nature-${categories.indexOf(value)}.png`:'nature-all.png';if(id==='nature'&&natureType&&value&&value!==example.value)return null;return image?<img key={id} data-map-layer={id} src={assets[image]} alt="" draggable={false} style={{opacity:1-transparency[id]/100}}/>:null})}
            {sampleVisible&&transparency.nature<100&&<button className={`object-marker ${selected?'selected':''}`} style={{left:'57.8%',top:'71.4%'}} onPointerDown={e=>e.stopPropagation()} onClick={chooseObject} aria-label={`Vis lokalitet ${example.name}`} title={example.name}><span/><span className="sr-only">{example.name}</span></button>}
          </div></div>
          <div className="map-zoom"><button className="icon-button" onClick={()=>setScale(p=>Math.min(3,p+.25))} aria-label="Zoom inn"><Icon name="plus"/></button><button className="icon-button" onClick={()=>setScale(p=>Math.max(.8,p-.25))} aria-label="Zoom ut"><Icon name="minus"/></button></div>
          <div className="map-north" aria-hidden="true"><span>↑</span>N</div>
          {active.includes('nature')&&filtered&&<button className="map-filter-chip" onClick={()=>open('nature')}><Icon name="settings"/><span>{natureType||value}{natureType&&value?' · '+value:''}</span><span className="sr-only">Åpne naturtypefilter</span></button>}
          {!active.length&&<div className="empty-map-message"><Icon name="layers"/><span><strong>Bakgrunnskartet vises</strong>Alle kartlag er slått av.</span></div>}
          {active.length>=5&&<button className="many-layers-note" onClick={()=>open('legend')}><Icon name="layers"/>{active.length} lag vises · Se tegnforklaring <Icon name="arrow"/></button>}
          <button className="floating-legend" onClick={()=>open('legend')}><Icon name="legend"/><span>Tegnforklaring</span></button>
          <div className="map-credit">Kartbilder: Kartverket, NIBIO, DiBK og Miljødirektoratet</div>
        </div>
        <div className="map-footer"><span><span className="status-dot"/>{active.length?`${active.length} aktive kartlag`:'Ingen aktive kartlag'}</span><button onClick={()=>open('help')}>Designmock · arkiverte kartbilder <Icon name="info"/></button></div>
      </section>
      {panel&&<aside ref={panelRef} className="detail-panel" aria-labelledby="detail-title">
        <div className="detail-header"><button className="icon-button detail-back" onClick={close} aria-label="Tilbake til kartlag"><Icon name="back"/></button><div><p className="eyebrow">{source?.group|| (panel==='object'?'Verdsatte naturtyper':'Kartvisning')}</p><h2 id="detail-title">{source?.name||(panel==='legend'?'Tegnforklaring':panel==='object'?'Valgt lokalitet':'Om prototypen')}</h2></div><button className="icon-button" onClick={close} aria-label="Lukk detaljpanel"><Icon name="close"/></button></div>
        <div className="detail-scroll">
        {source&&<>
          {!active.includes(source.id)&&<div className="info-box">Laget er slått av.<button onClick={()=>toggle(source.id)}>Slå på {source.name}</button></div>}
          {source.reference&&<p className="reference-note">{source.reference}</p>}
          {source.id==='nature'&&<>
            <section className="filter-section"><div className="section-title"><h3>Filtrer naturtyper</h3>{filtered&&<button className="text-button" onClick={()=>{changeFilter('','');setSearch('')}}>Nullstill</button>}</div><p className="small-muted">Endrer bare Verdsatte naturtyper.</p>
              <label htmlFor="nature-type">Naturtype</label><select id="nature-type" value={natureType} onChange={e=>changeFilter(e.target.value,value)}><option value="">Alle registrerte naturtyper</option>{(!search||example.type.toLocaleLowerCase('nb').includes(search.toLocaleLowerCase('nb'))||natureType===example.type)&&<option>{example.type}</option>}</select>
              {search&&!example.type.toLocaleLowerCase('nb').includes(search.toLocaleLowerCase('nb'))&&<p className="small-muted" role="status">Ingen samsvar i designutvalget.</p>}
              <label htmlFor="value-category">Verdikategori</label><select id="value-category" value={value} onChange={e=>changeFilter(natureType,e.target.value)}><option value="">Alle fire verdikategorier</option>{categories.map(v=><option key={v}>{v}</option>)}</select>
              <details className="type-search-details"><summary>Søk i naturtypenavn</summary><label className="sr-only" htmlFor="type-search">Søk i naturtyper</label><div className="search-field"><Icon name="search"/><input id="type-search" type="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Skriv naturtypenavn"/></div></details>
              <p className="filter-status" role="status">{natureType?`${sampleVisible?'1 dokumentert lokalitet':'Ingen lokaliteter'} i designutvalget`:(value?`${value} i kartutsnittet`:'Alle registrerte verdikategorier i kartutsnittet')}</p>
              <p className="small-muted">Designutvalget demonstrerer én dokumentert naturtype. Full kommuneliste kobles til ved eventuell implementering.</p>
            </section>
            <section className="locality-section"><h3>Lokaliteter</h3>{sampleVisible?<button className={`locality-card ${selected?'is-selected':''}`} onClick={chooseObject}><span><strong>{example.name}</strong><small>{example.type}</small><span className="value-label"><i style={{background:colors[1]}}/>{example.value}</span></span><Icon name="arrow"/></button>:<p>Ingen lokaliteter i dette designutvalget. Dette sier ikke noe om naturverdiene i kommunen.</p>}</section>
          </>}
          {source.id==='grey'&&<section className="filter-section"><h3>Framstilling</h3><p className="small-muted">Kildens avgrensning eller vegetasjonsestimater.</p><fieldset className="presentation-choices"><legend className="sr-only">Framstilling for Grå arealer</legend>{greyOptions.map(([id,label])=><label key={id}><input type="radio" name="grey" checked={grey===id} onChange={()=>{setGrey(id);setNotice(`${label} vises.`)}}/>{label}</label>)}</fieldset><p className="small-muted">Vises ved 1:250 000 eller nærmere i dagens karttjeneste. Bildemockens zoom endrer ikke kildeoppløsningen.</p></section>}
          <section className="opacity-section"><label htmlFor="transparency">Gjennomsiktighet <output>{transparency[source.id]} %</output></label><input id="transparency" aria-label={`Gjennomsiktighet for ${source.name}`} type="range" min="0" max="100" step="5" value={transparency[source.id]} onChange={e=>setTransparency(p=>({...p,[source.id]:+e.target.value}))}/><div className="range-labels"><span>Ugjennomsiktig</span><span>Helt gjennomsiktig</span></div></section>
          <section className="legend-section"><h3>Tegnforklaring</h3><Legend layer={source} grey={grey}/></section><SourceInfo layer={source}/>
        </>}
        {panel==='legend'&&<><p className="small-muted">Bare aktive lag. Rekkefølgen nedenfor følger kartet, med øverste lag først.</p>{!active.length&&<div className="info-box">Ingen aktive kartlag. Bakgrunnskartet fra Kartverket vises.</div>}{[...zOrder].reverse().filter(id=>active.includes(id)).map(id=>{const layer=layers.find(l=>l.id===id)!;return <section className="legend-section" key={id}><h3>{layer.name}</h3><p className="small-muted">{layer.group} · {transparency[id]} % gjennomsiktighet</p>{layer.reference&&<p className="reference-note">{layer.reference}</p>}<Legend layer={layer} grey={grey}/><SourceInfo layer={layer}/></section>})}</>}
        {panel==='object'&&<><button className="text-button" onClick={()=>open('nature')}><Icon name="back"/>Til naturtypefilter</button><section className="object-card"><Icon name="pin"/><h3>{example.name}</h3><p>{example.type}</p><span className="value-label"><i style={{background:colors[1]}}/>{example.value}</span></section><dl className="object-attributes"><dt>Kommunekontekst</dt><dd>Trondheim · 5001</dd><dt>Objekt-ID</dt><dd>{example.id}</dd><dt>Kilde-ID</dt><dd>{example.sourceId}</dd><dt>Kilde</dt><dd>Miljødirektoratet<br/>Naturtyper med KU-verdi</dd></dl><p className="small-muted">Faktiske felter fra lokaliteten i repoets valideringsbilde. Kommunen er valgt kartkontekst.</p><div className="info-box">Registrert lokalitet i et datasett som ikke er heldekkende. Manglende registrering betyr ikke fravær av naturverdi.</div><button className="secondary-button" onClick={()=>{setSelected(false);setPanel('nature');setNotice('Lokalitetsvalget er fjernet.')}}>Fjern lokalitetsvalg</button></>}
        {panel==='help'&&<><div className="info-box"><strong>Separat designmock</strong><p>Kartbilder og eksempellokalitet kommer fra faktisk validering i V3-repoet. Kombinasjoner, gjennomsiktighet og kategorifilter demonstreres med arkiverte bildepiksler.</p></div><p>Prototypen prøver plassering og interaksjon. Den gjør ingen analyser eller arealberegninger. Bildene har begrenset detalj, og er ikke en oppdatert karttjeneste.</p><p>Naturtypefilteret demonstrerer Frisk lågurtfuruskog og lokaliteten Elvåsan sør 2. Andre lags objektinspeksjon er ikke innført.</p><p>Sju eksisterende lag er tilgjengelige. FKB-Grønnstruktur inngår ikke; offentlig bruksrett er uavklart.</p><p>Bruk pilene når kartet har fokus for å flytte utsnittet. Pluss/minus zoomer bildet. Escape lukker panel. Lag- og filtervalg beholder utsnittet.</p><a href="rapport.html" target="_blank" rel="noreferrer">Les designvurdering og browserkontroll ↗</a></>}
        </div>
      </aside>}
      <nav className="mobile-nav" aria-label="Kartkontroller"><button onClick={()=>{setLayerOpen(!layerOpen);setPanel(null)}} aria-expanded={layerOpen}><Icon name="layers"/><span>Kartlag ({active.length})</span></button><button onClick={()=>{if(!active.includes('nature')){setActive(p=>[...p,'nature'])}open('nature')}} aria-expanded={panel==='nature'}><Icon name="settings"/><span>Naturtypefilter</span></button><button onClick={()=>open('legend')} aria-expanded={panel==='legend'}><Icon name="legend"/><span>Tegnforklaring</span></button></nav>
    </main><p className="sr-only" role="status" aria-live="polite">{notice}</p>
  </>
}

