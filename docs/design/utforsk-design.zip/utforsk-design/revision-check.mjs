import {chromium} from 'playwright'
import assert from 'node:assert/strict'
import {mkdir,writeFile} from 'node:fs/promises'
const root=process.env.PROTOTYPE_URL||'http://localhost:4175/'
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']})
const page=await browser.newPage({viewport:{width:1440,height:960},reducedMotion:'reduce'})
const checks=[],errors=[],comparison=[]
page.on('pageerror',error=>errors.push(error.message))
await mkdir('revisjon/bilder',{recursive:true})
async function metric(){return page.evaluate(()=>{const map=document.querySelector('.map'),image=document.querySelector('.map-image-stack'),m=map.getBoundingClientRect(),i=image.getBoundingClientRect(),matrix=new DOMMatrix(getComputedStyle(image).transform);return {width:innerWidth,height:innerHeight,documentWidth:document.documentElement.scrollWidth,map:{x:m.x,y:m.y,width:m.width,height:m.height,bottom:m.bottom},image:{x:i.x,y:i.y,width:i.width,height:i.height,baseWidth:image.offsetWidth},view:{scale:matrix.a,x:matrix.e,y:matrix.f},centerPixel:{x:(m.x+m.width/2-i.x)/i.width,y:(m.y+m.height/2-i.y)/i.height},scrollY}})}
async function shot(name){await page.evaluate(()=>Promise.all([...document.images].map(i=>i.decode().catch(()=>{}))));await page.screenshot({path:`revisjon/bilder/${name}.png`});const metrics=await metric();assert(metrics.documentWidth<=metrics.width,`${name}: horizontal overflow`);return metrics}
async function openFilter(width){if(width<=700)await page.getByRole('button',{name:'Naturtypefilter',exact:true}).click();else{await page.getByRole('checkbox',{name:/^Verdsatte naturtyper/}).check();await page.getByRole('button',{name:'Innstillinger for Verdsatte naturtyper',exact:true}).click()}}
async function settle(){await page.waitForTimeout(80)}
const near=(actual,expected,tolerance=.001)=>assert(Math.abs(actual-expected)<=tolerance,`${actual} differs from ${expected}`)
try{
 for(const [width,height] of [[1440,960],[900,900],[390,844],[320,720]]){
  await page.setViewportSize({width,height})
  for(const version of ['foer','etter']){
   await page.goto(root+(version==='foer'?'revisjon/foer.html':''))
   const initial=await shot(`${version}-${width}-start`)
   await openFilter(width)
   await page.locator('#nature-type').selectOption('Frisk lågurtfuruskog');await page.locator('#value-category').selectOption('Stor verdi')
   const filtered=await shot(`${version}-${width}-filter`)
   comparison.push({version,width,height,initial,filtered})
   if(version==='etter'){
    near(initial.view.scale,filtered.view.scale);near(initial.view.x,filtered.view.x);near(initial.view.y,filtered.view.y)
    if(width<=700){near(initial.image.baseWidth,filtered.image.baseWidth,1);near(initial.centerPixel.x,filtered.centerPixel.x);near(initial.centerPixel.y,filtered.centerPixel.y);assert(filtered.map.height>=185);const sheet=await page.locator('.detail-panel').boundingBox();assert(filtered.map.bottom<=sheet.y+1)}
    await page.locator('.detail-header button').last().focus();await page.keyboard.press('Escape');await settle()
    const focus=await page.evaluate(()=>({name:document.activeElement.getAttribute('aria-label'),text:document.activeElement.textContent}))
    if(width<=700)assert.equal(focus.text,'Naturtypefilter');else assert.equal(focus.name,'Innstillinger for Verdsatte naturtyper')
    await openFilter(width);assert.equal(await page.locator('#nature-type').inputValue(),'Frisk lågurtfuruskog');assert.equal(await page.locator('#value-category').inputValue(),'Stor verdi')
    const reopened=await metric();near(reopened.view.scale,filtered.view.scale);near(reopened.view.x,filtered.view.x);near(reopened.view.y,filtered.view.y)
    checks.push({name:`${width}: close/reopen nature filter retains choices and returns focus`,result:'passed'})
    await page.getByRole('button',{name:'Vis lokalitet Elvåsan sør 2',exact:true}).click();assert(await page.getByRole('heading',{name:'Elvåsan sør 2',exact:true}).isVisible());assert.equal(await page.getByText('2089403',{exact:true}).count(),1)
    await shot(`etter-${width}-objekt`)
    await page.keyboard.press('Escape');await settle();assert.equal(await page.evaluate(()=>document.activeElement.getAttribute('aria-label')),'Vis lokalitet Elvåsan sør 2')
    checks.push({name:`${width}: filters, object, Escape/focus, no overflow, stable view`,result:'passed'})
   }
  }
 }
 for(const width of [390,320]){
  await page.setViewportSize({width,height:width===390?844:720});await page.goto(root)
  const initial=await metric();await page.getByRole('button',{name:'Kartlag (1)',exact:true}).click();const opened=await shot(`etter-${width}-lagpanel`)
  near(initial.image.baseWidth,opened.image.baseWidth,1);near(initial.centerPixel.x,opened.centerPixel.x);near(initial.centerPixel.y,opened.centerPixel.y)
  await page.getByRole('button',{name:'Lukk kartlag',exact:true}).click();await settle();assert.equal(await page.evaluate(()=>document.activeElement.textContent), 'Kartlag (1)');near((await metric()).image.baseWidth,initial.image.baseWidth,1)
  checks.push({name:`${width}: layer sheet does not shrink image or change center`,result:'passed'})
 }
 await page.setViewportSize({width:900,height:900});await page.goto(root)
 await openFilter(900);await page.getByRole('button',{name:'Tilbake til kartlag · 2',exact:true}).click();await settle();assert(await page.getByRole('checkbox',{name:'Grunnkart nivå 0',exact:true}).isVisible());assert.equal(await page.evaluate(()=>document.activeElement.getAttribute('aria-label')),'Innstillinger for Verdsatte naturtyper')
 await page.getByRole('checkbox',{name:'Framtidig utbygging',exact:true}).check();await page.getByRole('button',{name:'Innstillinger for Framtidig utbygging',exact:true}).click();await page.getByRole('button',{name:'Tilbake til kartlag',exact:true}).click();assert(await page.getByRole('checkbox',{name:'Framtidig utbygging',exact:true}).isChecked())
 await shot('etter-900-tilbake-til-lagvalg');checks.push({name:'900: visible return navigation, focus restoration, layer choice retained',result:'passed'})
 await page.setViewportSize({width:1440,height:960});await page.goto(root)
 for(const [fractionX,fractionY] of [[.5,.5],[.25,.3],[.75,.7]]){
  await page.getByRole('button',{name:'Vis hele kommunen',exact:true}).click();const before=await metric(),x=before.map.x+before.map.width*fractionX,y=before.map.y+before.map.height*fractionY
  const pixel={x:(x-before.image.x)/before.image.width,y:(y-before.image.y)/before.image.height}
  await page.mouse.move(x,y);await page.mouse.wheel(0,-180);await settle();const after=await metric();assert(after.view.scale>before.view.scale);near((x-after.image.x)/after.image.width,pixel.x);near((y-after.image.y)/after.image.height,pixel.y);near(after.scrollY,before.scrollY)
  await page.mouse.wheel(0,120);await settle();assert((await metric()).view.scale<after.view.scale)
  checks.push({name:`wheel anchor ${fractionX},${fractionY} and zoom in/out`,result:'passed',pixel,view:after.view})
 }
 let m=await metric();await page.mouse.move(m.map.x+m.map.width*.6,m.map.y+m.map.height*.4);await page.mouse.wheel(0,-5000);await settle()
 for(let i=0;i<8;i++){await page.mouse.wheel(0,-5000);await settle()};near((await metric()).view.scale,3)
 for(let i=0;i<12;i++){await page.mouse.wheel(0,5000);await settle()};near((await metric()).view.scale,.8)
 checks.push({name:'wheel honors min .8 and max 3',result:'passed'})
 await page.getByRole('button',{name:'Vis hele kommunen',exact:true}).click();m=await metric();const x=m.map.x+m.map.width*.55,y=m.map.y+m.map.height*.5
 await page.mouse.move(x,y);await page.mouse.wheel(0,-160);await settle();m=await metric();await page.mouse.down();await page.mouse.move(x+45,y+30,{steps:5});await page.mouse.up();const pan=await metric();near(pan.view.x,m.view.x+45);near(pan.view.y,m.view.y+30);near(pan.view.scale,m.view.scale)
 await page.getByRole('button',{name:'Zoom inn',exact:true}).click();assert((await metric()).view.scale>pan.view.scale)
 await page.getByRole('button',{name:'Zoom ut',exact:true}).click();near((await metric()).view.scale,pan.view.scale)
 await page.locator('#map').focus();await page.keyboard.press('ArrowLeft');near((await metric()).view.x,pan.view.x+35);await page.keyboard.press('+');assert((await metric()).view.scale>pan.view.scale)
 await shot('etter-1440-musehjul-og-pan');checks.push({name:'pan after wheel, buttons and keyboard preserved',result:'passed'})
 await page.setViewportSize({width:900,height:480});await page.goto(root);await page.evaluate(()=>{document.body.style.minHeight='1000px'})
 m=await metric();await page.mouse.move(m.map.x+m.map.width*.5,m.map.y+100);await page.mouse.wheel(0,120);await settle();near((await metric()).scrollY,0);checks.push({name:'wheel over map prevents page scrolling',result:'passed'})
 await page.setViewportSize({width:390,height:844});await page.goto(root);await openFilter(390);const unchanged=(await metric()).view;await page.mouse.move(210,700);await page.mouse.wheel(0,200);await settle();assert(await page.locator('.detail-scroll').evaluate(e=>e.scrollTop)>0);assert.deepEqual((await metric()).view,unchanged);checks.push({name:'panel scrolling remains usable and does not zoom map',result:'passed'})
 for(const width of [390,320]){const a=comparison.find(x=>x.width===width&&x.version==='foer').filtered,b=comparison.find(x=>x.width===width&&x.version==='etter').filtered;assert(b.map.height>a.map.height);assert(b.image.baseWidth>a.image.baseWidth);checks.push({name:`${width}: larger map viewport and image than before`,result:'passed',before:a,after:b})}
 assert.equal(errors.length,0);checks.push({name:'zero JavaScript errors',result:'passed'})
}catch(error){await page.screenshot({path:'revisjon/failure.png'});checks.push({name:'interrupted',result:'failed',message:error.message});throw error}
finally{await writeFile('revisjon/kontroller.json',JSON.stringify({date:'2026-10-12',checks,comparison,errors},null,2));console.log(`${checks.filter(c=>c.result==='passed').length} kontroller bestått; ${errors.length} JavaScript-feil.`);await browser.close()}
