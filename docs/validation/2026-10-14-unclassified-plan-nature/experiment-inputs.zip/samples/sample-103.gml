<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>274291.990478,7028323.996499 274374.086566,7028449.703700</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>skog</arealdekkeniva1>
			<arealdekkeniva2>skogLauv</arealdekkeniva2>
			<skogbonitet>lavBonitet</skogbonitet>
			<grunnforhold>jorddekt</grunnforhold>
			<arealbruklandhovedklasse>ikkeRegistert</arealbruklandhovedklasse>
			<arealbruklandunderklasse>ikkeRegistert</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>33</arealdekkekode>
			<skogbonitetkode>12</skogbonitetkode>
			<grunnforholdkode>44</grunnforholdkode>
			<arealbruklandkode>99999999</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>ikkeRelevant</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>3173.67646108908</am2>
			<omkrets>382.90838618436237</omkrets>
			<ff>1.9173826979553275</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>skog</okosystemtypeniva1>
			<okosystemtypeniva2>lovskog</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0410</okosystemtypekode>
			<id>16127934</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
