<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>272907.031475,7044227.231249 272977.329862,7044350.140600</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>samferdsel</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>TransportTelek</arealbruklandhovedklasse>
			<arealbruklandunderklasse>GangSykkelVeg</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>12</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>08040105</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ssbArealbruk</grunnkartkilde>
			<arealbrukkilde>FkbVeg</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>139.8300475028755</am2>
			<omkrets>303.63998906975223</omkrets>
			<ff>7.754338730551885</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>infrastruktur</okosystemtypeniva2>
			<okosystemtypeniva3>veiJernbane</okosystemtypeniva3>
			<okosystemtypekode>0131</okosystemtypekode>
			<id>16117661</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
