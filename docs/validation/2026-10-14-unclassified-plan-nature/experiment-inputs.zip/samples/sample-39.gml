<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>257622.810800,7041853.085400 257691.376600,7041891.158000</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>bebygd</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>Boligbebyggelse</arealbruklandhovedklasse>
			<arealbruklandunderklasse>FrittliggSmaahus</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>11</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>01010000</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ssbArealbruk</grunnkartkilde>
			<arealbrukkilde>ArealMedBygg</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>1276.4439064217293</am2>
			<omkrets>173.49894434607884</omkrets>
			<ff>1.3773839716507386</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>spredtBebyggelse</okosystemtypeniva2>
			<okosystemtypeniva3>spredtBoligbebyggelse</okosystemtypeniva3>
			<okosystemtypekode>0121</okosystemtypekode>
			<id>16074569</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
