<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>268545.097500,7031012.343857 268707.977607,7031080.650810</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>snaumark</arealdekkeniva1>
			<arealdekkeniva2>snaumarkFrisk</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>jorddekt</grunnforhold>
			<arealbruklandhovedklasse>ikkeRegistert</arealbruklandhovedklasse>
			<arealbruklandunderklasse>ikkeRegistert</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>55</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>44</grunnforholdkode>
			<arealbruklandkode>99999999</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>ikkeRelevant</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>7075.522208353248</am2>
			<omkrets>417.18242841860456</omkrets>
			<ff>1.3990782656179463</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>heiBuskmark</okosystemtypeniva1>
			<okosystemtypeniva2>heiBuskmark</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0520</okosystemtypekode>
			<id>16128918</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
