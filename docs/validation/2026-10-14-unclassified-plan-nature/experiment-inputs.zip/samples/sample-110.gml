<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>273660.085549,7026158.004300 273748.577041,7026415.058069</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>samferdsel</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>TransportTelek</arealbruklandhovedklasse>
			<arealbruklandunderklasse>AnnenVeg</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>12</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>08040107</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>Ar5</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>1972.5564726009243</am2>
			<omkrets>936.176609710625</omkrets>
			<ff>5.946183599490434</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>infrastruktur</okosystemtypeniva2>
			<okosystemtypeniva3>veiJernbane</okosystemtypeniva3>
			<okosystemtypekode>0131</okosystemtypekode>
			<id>16098467</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
