<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>280041.306545,7041473.766500 280050.200000,7041485.544053</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>samferdsel</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>TransportTelek</arealbruklandhovedklasse>
			<arealbruklandunderklasse>AnnenBilveg</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>12</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>08040104</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ssbArealbruk</grunnkartkilde>
			<arealbrukkilde>NvdbSsb</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>46.86176910483888</am2>
			<omkrets>30.840970192429044</omkrets>
			<ff>1.2709075008137893</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>infrastruktur</okosystemtypeniva2>
			<okosystemtypeniva3>veiJernbane</okosystemtypeniva3>
			<okosystemtypekode>0131</okosystemtypekode>
			<id>16092192</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
