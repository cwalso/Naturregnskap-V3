<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>274349.372906,7027582.618116 274507.997053,7027778.267754</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>skog</arealdekkeniva1>
			<arealdekkeniva2>skogGran</arealdekkeniva2>
			<skogbonitet>lavBonitet</skogbonitet>
			<grunnforhold>jorddekt</grunnforhold>
			<arealbruklandhovedklasse>ikkeRegistert</arealbruklandhovedklasse>
			<arealbruklandunderklasse>ikkeRegistert</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>31</arealdekkekode>
			<skogbonitetkode>12</skogbonitetkode>
			<grunnforholdkode>44</grunnforholdkode>
			<arealbruklandkode>99999999</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>ikkeRelevant</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>20221.577918890842</am2>
			<omkrets>659.9636954204805</omkrets>
			<ff>1.3092053654018156</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>skog</okosystemtypeniva1>
			<okosystemtypeniva2>barskog</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0420</okosystemtypekode>
			<id>16122948</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
