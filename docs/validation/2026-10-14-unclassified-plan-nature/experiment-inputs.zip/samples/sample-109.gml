<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>274405.989800,7028217.784400 274424.357300,7028243.904100</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>bebygd</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>Boligbebyggelse</arealbruklandhovedklasse>
			<arealbruklandunderklasse>KonsSmaahus</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>11</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>01020000</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ssbArealbruk</grunnkartkilde>
			<arealbrukkilde>ArealMedBygg</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>415.51713170397426</am2>
			<omkrets>78.80804560715805</omkrets>
			<ff>1.0906146860891184</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>tettBebyggelse</okosystemtypeniva2>
			<okosystemtypeniva3>tettBoligbebyggelse</okosystemtypeniva3>
			<okosystemtypekode>0111</okosystemtypekode>
			<id>16075977</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
