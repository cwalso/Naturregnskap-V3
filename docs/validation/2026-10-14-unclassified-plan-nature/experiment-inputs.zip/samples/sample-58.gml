<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>267414.282600,7035724.306669 269662.510886,7038921.853100</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>samferdsel</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>TransportTelek</arealbruklandhovedklasse>
			<arealbruklandunderklasse>AnnenBilveg</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>12</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>08040104</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ssbArealbruk</grunnkartkilde>
			<arealbrukkilde>FkbVeg</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>246440.89815950042</am2>
			<omkrets>88279.00229069799</omkrets>
			<ff>50.16773199915121</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>infrastruktur</okosystemtypeniva2>
			<okosystemtypeniva3>veiJernbane</okosystemtypeniva3>
			<okosystemtypekode>0131</okosystemtypekode>
			<id>16065849</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
