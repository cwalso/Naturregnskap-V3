<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>270949.381300,7027087.547081 271123.456485,7027267.592891</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>snaumark</arealdekkeniva1>
			<arealdekkeniva2>snaumarkKonstruert</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>konstruert</grunnforhold>
			<arealbruklandhovedklasse>ikkeRegistert</arealbruklandhovedklasse>
			<arealbruklandunderklasse>ikkeRegistert</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>56</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>46</grunnforholdkode>
			<arealbruklandkode>99999999</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>ikkeRelevant</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>2438.113412317205</am2>
			<omkrets>588.5281278700612</omkrets>
			<ff>3.3622927469914647</ff>
			<kystsone></kystsone>
			<bebygdmaske>Ja</bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>ikkeRegistrert</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0100</okosystemtypekode>
			<id>16131847</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
