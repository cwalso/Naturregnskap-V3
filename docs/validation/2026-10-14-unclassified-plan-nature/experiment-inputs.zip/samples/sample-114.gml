<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>274026.315400,7027665.987004 274339.771900,7028163.588200</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>samferdsel</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>TransportTelek</arealbruklandhovedklasse>
			<arealbruklandunderklasse>AnnenBilveg</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>12</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>08040104</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ssbArealbruk</grunnkartkilde>
			<arealbrukkilde>FkbVeg</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>4859.635191426743</am2>
			<omkrets>2066.4879946915853</omkrets>
			<ff>8.36231077972648</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>infrastruktur</okosystemtypeniva2>
			<okosystemtypeniva3>veiJernbane</okosystemtypeniva3>
			<okosystemtypekode>0131</okosystemtypekode>
			<id>16066725</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
