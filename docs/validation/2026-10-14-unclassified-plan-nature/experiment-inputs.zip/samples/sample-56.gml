<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>268061.493033,7031435.183444 268121.085221,7031590.262300</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>skog</arealdekkeniva1>
			<arealdekkeniva2>skogFuru</arealdekkeniva2>
			<skogbonitet>middelsBonitet</skogbonitet>
			<grunnforhold>jorddekt</grunnforhold>
			<arealbruklandhovedklasse>ikkeRegistert</arealbruklandhovedklasse>
			<arealbruklandunderklasse>ikkeRegistert</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>32</arealdekkekode>
			<skogbonitetkode>13</skogbonitetkode>
			<grunnforholdkode>44</grunnforholdkode>
			<arealbruklandkode>99999999</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>ikkeRelevant</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>2743.2278761108396</am2>
			<omkrets>357.04045416007534</omkrets>
			<ff>1.9510216438661014</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>skog</okosystemtypeniva1>
			<okosystemtypeniva2>barskog</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0420</okosystemtypekode>
			<id>16145934</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
