<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>280072.001543,7039980.391475 280261.597611,7040148.023801</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>skog</arealdekkeniva1>
			<arealdekkeniva2>skogGran</arealdekkeniva2>
			<skogbonitet>middelsBonitet</skogbonitet>
			<grunnforhold>grunnlendt</grunnforhold>
			<arealbruklandhovedklasse>ikkeRegistert</arealbruklandhovedklasse>
			<arealbruklandunderklasse>ikkeRegistert</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>31</arealdekkekode>
			<skogbonitetkode>13</skogbonitetkode>
			<grunnforholdkode>43</grunnforholdkode>
			<arealbruklandkode>99999999</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>ikkeRelevant</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>19832.587006739956</am2>
			<omkrets>856.539947458014</omkrets>
			<ff>1.715746769113096</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>skog</okosystemtypeniva1>
			<okosystemtypeniva2>barskog</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0420</okosystemtypekode>
			<id>16123548</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
