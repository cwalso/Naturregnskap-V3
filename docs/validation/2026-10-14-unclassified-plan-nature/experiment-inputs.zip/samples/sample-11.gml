<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>274943.538712,7042137.011783 275016.606400,7042191.889700</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>bebygd</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>HelseSosial</arealbruklandhovedklasse>
			<arealbruklandunderklasse>SykehjemMm</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>11</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>06020000</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ssbArealbruk</grunnkartkilde>
			<arealbrukkilde>ArealMedBygg</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>2614.720552196773</am2>
			<omkrets>207.90270160714118</omkrets>
			<ff>1.1469454000574664</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>tettBebyggelse</okosystemtypeniva2>
			<okosystemtypeniva3>tettNaringsbebyggelse</okosystemtypeniva3>
			<okosystemtypekode>0112</okosystemtypekode>
			<id>16079469</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
