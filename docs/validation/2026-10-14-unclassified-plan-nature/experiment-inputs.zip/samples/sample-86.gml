<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>264678.088000,7031116.776700 264752.732100,7031187.199000</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>bebygd</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>GroenneOmr</arealbruklandhovedklasse>
			<arealbruklandunderklasse>Lekeplass</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>11</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>12040000</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ssbArealbruk</grunnkartkilde>
			<arealbrukkilde>FkbArealbruk</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>2643.6786736516488</am2>
			<omkrets>232.44306280996616</omkrets>
			<ff>1.2759359312640035</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>gronneArealer</okosystemtypeniva2>
			<okosystemtypeniva3>sportFriluftsomrader</okosystemtypeniva3>
			<okosystemtypekode>0142</okosystemtypekode>
			<id>16085850</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
