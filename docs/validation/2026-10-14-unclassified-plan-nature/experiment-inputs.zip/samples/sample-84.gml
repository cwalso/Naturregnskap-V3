<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>271233.514527,7027716.844300 271272.623369,7027753.795935</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>bebygdSamferdsel</arealdekkeniva1>
			<arealdekkeniva2>bebygd</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>ikkeRelevant</grunnforhold>
			<arealbruklandhovedklasse>UklassifisertBeb</arealbruklandhovedklasse>
			<arealbruklandunderklasse>UklassifisertBeb</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>11</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>98</grunnforholdkode>
			<arealbruklandkode>14000000</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>Ar5</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>918.8532980578333</am2>
			<omkrets>133.80367374912186</omkrets>
			<ff>1.245203118945456</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>bebygdOpparbeidetAreal</okosystemtypeniva1>
			<okosystemtypeniva2>ikkeRegistrert</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0100</okosystemtypekode>
			<id>16087259</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
