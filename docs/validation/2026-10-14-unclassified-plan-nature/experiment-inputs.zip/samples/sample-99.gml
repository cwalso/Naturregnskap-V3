<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>274381.304269,7025232.017388 274799.998630,7025899.998808</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>skog</arealdekkeniva1>
			<arealdekkeniva2>skogGran</arealdekkeniva2>
			<skogbonitet>middelsBonitet</skogbonitet>
			<grunnforhold>jorddekt</grunnforhold>
			<arealbruklandhovedklasse>ikkeRegistert</arealbruklandhovedklasse>
			<arealbruklandunderklasse>ikkeRegistert</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>31</arealdekkekode>
			<skogbonitetkode>13</skogbonitetkode>
			<grunnforholdkode>44</grunnforholdkode>
			<arealbruklandkode>99999999</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>ikkeRelevant</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>134552.07617831757</am2>
			<omkrets>2793.1991129833227</omkrets>
			<ff>2.1496618409137316</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>skog</okosystemtypeniva1>
			<okosystemtypeniva2>barskog</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0420</okosystemtypekode>
			<id>16148797</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
