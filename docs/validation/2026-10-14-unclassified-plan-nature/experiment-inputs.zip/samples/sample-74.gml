<?xml version="1.0" encoding="UTF-8"?>

<msGMLOutput 
	 xmlns:gml="http://www.opengis.net/gml"
	 xmlns:xlink="http://www.w3.org/1999/xlink"
	 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<okosystemtype_layer>
	<gml:name>Økosystemtype nivå 1</gml:name>
		<okosystemtype_feature>
			<gml:boundedBy>
				<gml:Box srsName="EPSG:25833">
					<gml:coordinates>273958.928523,7038114.150345 274314.189660,7039000.407583</gml:coordinates>
				</gml:Box>
			</gml:boundedBy>
			<arealdekkeniva1>snaumark</arealdekkeniva1>
			<arealdekkeniva2>snaumarkUspesifisert</arealdekkeniva2>
			<skogbonitet>ikkeRelevant</skogbonitet>
			<grunnforhold>jorddekt</grunnforhold>
			<arealbruklandhovedklasse>ikkeRegistert</arealbruklandhovedklasse>
			<arealbruklandunderklasse>ikkeRegistert</arealbruklandunderklasse>
			<arealbrukhav>ikkeRelevant</arealbrukhav>
			<arealdekkekode>59</arealdekkekode>
			<skogbonitetkode>98</skogbonitetkode>
			<grunnforholdkode>44</grunnforholdkode>
			<arealbruklandkode>99999999</arealbruklandkode>
			<arealbrukhavkode>988888</arealbrukhavkode>
			<grunnkartkilde>ar5</grunnkartkilde>
			<arealbrukkilde>ikkeRelevant</arealbrukkilde>
			<kommunenummer>5001</kommunenummer>
			<am2>15594.519153388714</am2>
			<omkrets>3921.7796402469357</omkrets>
			<ff>8.864011555898394</ff>
			<kystsone></kystsone>
			<bebygdmaske></bebygdmaske>
			<okosystemtypeniva1>heiBuskmark</okosystemtypeniva1>
			<okosystemtypeniva2>heiBuskmark</okosystemtypeniva2>
			<okosystemtypeniva3>ikkeRegistrert</okosystemtypeniva3>
			<okosystemtypekode>0520</okosystemtypekode>
			<id>16062377</id>
		</okosystemtype_feature>
	</okosystemtype_layer>
</msGMLOutput>
